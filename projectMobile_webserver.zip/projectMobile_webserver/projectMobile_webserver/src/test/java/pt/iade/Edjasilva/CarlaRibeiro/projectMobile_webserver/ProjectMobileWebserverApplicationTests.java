package pt.iade.Edjasilva.CarlaRibeiro.projectMobile_webserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectMobileWebserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
